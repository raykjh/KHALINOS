extends SceneTree

func _initialize() -> void:
    call_deferred("_probe")

func _probe() -> void:
    var output := ""
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--output="):
            output = argument.trim_prefix("--output=")
    if output.is_empty():
        quit(2)
        return
    var packed = load("res://scenes/gameplay.tscn")
    var instance = packed.instantiate() if packed != null else null
    if instance != null:
        root.add_child(instance)
        await process_frame
    var receipt: Dictionary = instance.verification_scenario() if instance != null else {}
    receipt.passed = (
        receipt.get("start_gate_present", false)
        and receipt.get("countdown_decrements", false)
        and receipt.get("first_enemy_level_one_beatable", false)
        and receipt.get("all_hero_basic_attacks_visible", false)
        and receipt.get("skill_cooldown_enforced", false)
        and receipt.get("skill_effect_visible", false)
        and receipt.get("heal_effect_visible", false)
        and receipt.get("enemy_attack_effect_visible", false)
        and receipt.get("enemy_attack_cooldown_enforced", false)
        and receipt.get("level_choice_prompted", false)
        and receipt.get("enemy_visual_family", "") == "green"
        and receipt.get("background_visual_treatment", "") == "bright_readable"
        and receipt.get("outcome_prompt_present", false)
        and receipt.get("movement_applied", false)
        and receipt.get("enemy_spawned", false)
        and receipt.get("auto_ability_applied", false)
        and receipt.get("shared_health_initialized", false)
        and receipt.get("level_choice_offered", false)
        and receipt.get("level_choice_applied", false)
        and receipt.get("upgrade_role_order_valid", false)
        and receipt.get("upgrade_choice_contract_valid", false)
        and receipt.get("profession_choice_mode", "") == "seeded_random_alternatives"
        and receipt.get("seeded_alternatives_valid", false)
        and receipt.get("same_seed_repeatable", false)
        and receipt.get("different_seed_variation_when_possible", false)
        and receipt.get("resurrection_stored", false)
        and receipt.get("resurrection_consumed", false)
        and receipt.get("victory_at_session_end", false)
        and (
            not FileAccess.file_exists("res://KHALINOS_SPRITE_ATLAS.json")
            or (receipt.get("sprite_atlas_loaded", false) and receipt.get("all_sprite_ids_mapped", false))
        )
    )
    var target := FileAccess.open(output, FileAccess.WRITE)
    target.store_string(JSON.stringify(receipt))
    target.close()
    if instance != null:
        instance.queue_free()
    quit(0 if receipt.passed else 1)
